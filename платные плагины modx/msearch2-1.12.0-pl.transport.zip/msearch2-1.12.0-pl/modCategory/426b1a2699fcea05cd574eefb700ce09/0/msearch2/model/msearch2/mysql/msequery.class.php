<?php
require_once (dirname(__DIR__) . '/msequery.class.php');
class mseQuery_mysql extends mseQuery {}